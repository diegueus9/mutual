-- phpMyAdmin SQL Dump
-- version 2.9.0.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 21-01-2007 a las 20:50:28
-- Versión del servidor: 5.0.27
-- Versión de PHP: 5.2.0
-- 
-- Base de datos: `mutual`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `grupos_etareos`
-- 

CREATE TABLE `grupos_etareos` (
  `COD_GRUPO` int(11) NOT NULL,
  `FRECUENCIA` int(11) NOT NULL,
  `GENERO` varchar(1) collate utf8_spanish_ci NOT NULL,
  `VALOR_MAXIMO` int(11) NOT NULL,
  `VALOR_MINIMO` int(11) NOT NULL,
  `DESCRIPCION` text collate utf8_spanish_ci NOT NULL,
  `FRECUENCIA_METAS` int(10) NOT NULL,
  PRIMARY KEY  (`COD_GRUPO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `grupos_etareos`
-- 

INSERT INTO `grupos_etareos` (`COD_GRUPO`, `FRECUENCIA`, `GENERO`, `VALOR_MAXIMO`, `VALOR_MINIMO`, `DESCRIPCION`, `FRECUENCIA_METAS`) VALUES 
(99, 9, 'F', 588, 120, 'MMMMM N N N MM ', 1),
(100, 2, 'M', 840, 360, '', 2),
(101, 4, 'M', 840, 180, 'Hombres entre 15 y 70 años', 3);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tactivacion`
-- 

CREATE TABLE `tactivacion` (
  `COD_ACTIVACION` int(10) NOT NULL auto_increment,
  `COD_AFILIADO` char(13) collate utf8_spanish_ci NOT NULL,
  `COD_MES` int(11) NOT NULL,
  `CONSECTUVO2` int(11) NOT NULL,
  `CONTRATO` int(11) default NULL,
  `FECHA_ACTIVACION` date default NULL,
  PRIMARY KEY  (`COD_ACTIVACION`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `tactivacion`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tactividad_programar`
-- 

CREATE TABLE `tactividad_programar` (
  `COD_ACTIVIDAD_PROGRAMAR` int(11) NOT NULL,
  `COD_AFILIADO` char(13) collate utf8_spanish_ci NOT NULL,
  `COD_PROGRAMA` int(11) default NULL,
  `COD_CUPS` char(6) collate utf8_spanish_ci default NULL,
  `FECHA_PROGRAMO` date default NULL,
  `FIRMA_NEGACION` longblob,
  PRIMARY KEY  (`COD_ACTIVIDAD_PROGRAMAR`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `tactividad_programar`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tactividad_x_programa`
-- 

CREATE TABLE `tactividad_x_programa` (
  `COD_PROGRAMA` int(11) NOT NULL,
  `COD_CUPS` char(6) collate utf8_spanish_ci NOT NULL,
  `ESTADO` tinyint(1) default NULL,
  PRIMARY KEY  (`COD_PROGRAMA`,`COD_CUPS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `tactividad_x_programa`
-- 

INSERT INTO `tactividad_x_programa` (`COD_PROGRAMA`, `COD_CUPS`, `ESTADO`) VALUES 
(123, '147', 1),
(123, '456', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tactividadfiltrar`
-- 

CREATE TABLE `tactividadfiltrar` (
  `COD_ACTIVIDAD` decimal(10,0) NOT NULL,
  `GENERO` char(1) collate utf8_spanish_ci default NULL,
  `FRECUENCIA` int(11) default NULL,
  `INDICE1` int(11) default NULL,
  `INDICE2` int(11) default NULL,
  PRIMARY KEY  (`COD_ACTIVIDAD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `tactividadfiltrar`
-- 

INSERT INTO `tactividadfiltrar` (`COD_ACTIVIDAD`, `GENERO`, `FRECUENCIA`, `INDICE1`, `INDICE2`) VALUES 
(258, NULL, 1, NULL, NULL),
(369, NULL, 3, NULL, NULL),
(789, NULL, 2, NULL, NULL);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tactualizacion`
-- 

CREATE TABLE `tactualizacion` (
  `COD_ACTUALIZACION` int(10) NOT NULL auto_increment,
  `COD_TIPO_IDENTIFICACION2` char(3) collate utf8_spanish_ci default NULL,
  `COD_ACT` int(11) default NULL,
  `COD_ENTIDAD_CONTRATANTE` char(6) collate utf8_spanish_ci NOT NULL,
  `COD_AFILIADO` char(13) collate utf8_spanish_ci NOT NULL,
  `FECHA_ACTUALIZACION` date NOT NULL,
  `CONSECUTIVO1` int(11) NOT NULL,
  `FOTO` longblob,
  `CARNE_ENTIDAD_CONTRATANTE` longblob,
  `DOCUMENTO_IDENTIDAD` longblob,
  `DIRECCION_ACTUAL` char(30) collate utf8_spanish_ci default NULL,
  `TELEFONO_ACTUAL` char(11) collate utf8_spanish_ci default NULL,
  `CELULAR1` bigint(20) default NULL,
  `CELULAR2` bigint(20) default NULL,
  `RESPONSABLE_MEDICO` char(30) collate utf8_spanish_ci default NULL,
  `TELEFONO_RESPONSABLE_MEDICO` char(30) collate utf8_spanish_ci default NULL,
  `EMAIL` char(25) collate utf8_spanish_ci default NULL,
  `TIPO_DOCUMENTO_IDENTIDAD` char(3) collate utf8_spanish_ci default NULL,
  `DOCUMENTO_IDENTIDAD_ACT` char(16) collate utf8_spanish_ci default NULL,
  `PRIMER_NOMBRE_ACT` char(20) collate utf8_spanish_ci default NULL,
  `SEGUNDO_NOMBRE_ACT` char(20) collate utf8_spanish_ci default NULL,
  `PRIMER_APELLIDO_ACT` char(20) collate utf8_spanish_ci default NULL,
  `SEGUNDO_APELLIDO_ACTS` char(20) collate utf8_spanish_ci default NULL,
  `FECHA_NACIMIENTO_ACT` date default NULL,
  `ESTADO` tinyint(1) default NULL,
  `TIPO_ACTUALIZACION` int(11) default NULL,
  PRIMARY KEY  (`COD_ACTUALIZACION`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `tactualizacion`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tafiliados`
-- 

CREATE TABLE `tafiliados` (
  `COD_AFILIADO` char(13) collate utf8_spanish_ci NOT NULL,
  `COD_MUN` char(3) collate utf8_spanish_ci default NULL,
  `COD_TIPO_IDENTIFICACION2` char(3) collate utf8_spanish_ci default NULL,
  `COD_PARENTESCO2` char(1) collate utf8_spanish_ci default NULL,
  `COD_TIPO_AFILIADO2` char(1) collate utf8_spanish_ci default NULL,
  `COD_ENTIDAD_CONTRATANTE2` char(6) collate utf8_spanish_ci default NULL,
  `COD_TIPO_CONTRATO` int(11) NOT NULL,
  `COD_ZONA2` char(1) collate utf8_spanish_ci default NULL,
  `COD_SEXO2` char(2) collate utf8_spanish_ci default NULL,
  `COD_PERTENENCIA_ETNICA2` char(2) collate utf8_spanish_ci default NULL,
  `COD_NIVEL_SISBEN2` char(1) collate utf8_spanish_ci default NULL,
  `TTI_COD_TIPO_IDENTIFICACION2` char(3) collate utf8_spanish_ci default NULL,
  `COD_GRUP_POBLACIONAL` char(2) collate utf8_spanish_ci default NULL,
  `COD_DEP` char(2) collate utf8_spanish_ci NOT NULL,
  `TAF_COD_AFILIADO` char(13) collate utf8_spanish_ci default NULL,
  `COD_ESTADO_AFILIACION2` char(2) collate utf8_spanish_ci default NULL,
  `COD_ARS` char(6) collate utf8_spanish_ci NOT NULL,
  `TIPO_IDENTIFICACION_CABEZA_FAMILIA` char(3) collate utf8_spanish_ci NOT NULL,
  `NUMERO_IDENTIFICACION_CABEZA_FAMILIA` char(16) collate utf8_spanish_ci NOT NULL,
  `TIPO_IDENTIFICACION` char(3) collate utf8_spanish_ci NOT NULL,
  `NUMERO_IDENTIFICACION` char(16) collate utf8_spanish_ci NOT NULL,
  `PRIMER_APELLIDO` char(20) collate utf8_spanish_ci NOT NULL,
  `SEGUNDO_APELLIDO` char(20) collate utf8_spanish_ci NOT NULL,
  `PRIMER_NOMBRE` char(20) collate utf8_spanish_ci NOT NULL,
  `SEGUNDO_NOMBRE` char(20) collate utf8_spanish_ci NOT NULL,
  `EDAD` int(11) NOT NULL,
  `FECHA_NACIMIENTO` date NOT NULL,
  `SEXO` char(2) collate utf8_spanish_ci NOT NULL,
  `TIPO_AFILIADO` char(1) collate utf8_spanish_ci NOT NULL,
  `PARENTESCO_CABEZA_FAMILIA` char(1) collate utf8_spanish_ci NOT NULL,
  `GRUPO_POBLACIONAL` char(1) collate utf8_spanish_ci NOT NULL,
  `NIVEL_SISBEN` int(11) NOT NULL,
  `NUMERO_FICHA_SISBEN` char(13) collate utf8_spanish_ci NOT NULL,
  `NUCLEO_FAMILIAR_SISBEN` char(5) collate utf8_spanish_ci NOT NULL,
  `COD_DEPARTAMENTO` char(2) collate utf8_spanish_ci NOT NULL,
  `COD_MUNICIPIO` char(3) collate utf8_spanish_ci NOT NULL,
  `ZONA` char(1) collate utf8_spanish_ci NOT NULL,
  `FEC_AFILIACION_SGSSS` date NOT NULL,
  `FEC_AFILIACION_ENTIDAD_CONTRATANTE` date NOT NULL,
  `NUM_CONTRATO_ENTE_TERRITORIAL` char(10) collate utf8_spanish_ci NOT NULL,
  `FECHA_INICIO_CONTRATO_ENTE_TERRITORIAL` date NOT NULL,
  `TIPO_CONTRATO_ENTE_TERRITORIAL` char(2) collate utf8_spanish_ci NOT NULL,
  `PERTENENCIA_ETNICA` char(2) collate utf8_spanish_ci NOT NULL,
  `ESTADO_AFILIACION` char(2) collate utf8_spanish_ci NOT NULL,
  `DIRECCION` char(30) collate utf8_spanish_ci default NULL,
  `TELEFONO` char(20) collate utf8_spanish_ci default NULL,
  `LOCALIDAD` char(2) collate utf8_spanish_ci default NULL,
  `FECHA_CARNETIZACION` date default NULL,
  `BARRIO` char(30) collate utf8_spanish_ci default NULL,
  `COD_IPS` char(11) collate utf8_spanish_ci default NULL,
  `COD_CONTRATO` char(10) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`COD_AFILIADO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `tafiliados`
-- 

INSERT INTO `tafiliados` (`COD_AFILIADO`, `COD_MUN`, `COD_TIPO_IDENTIFICACION2`, `COD_PARENTESCO2`, `COD_TIPO_AFILIADO2`, `COD_ENTIDAD_CONTRATANTE2`, `COD_TIPO_CONTRATO`, `COD_ZONA2`, `COD_SEXO2`, `COD_PERTENENCIA_ETNICA2`, `COD_NIVEL_SISBEN2`, `TTI_COD_TIPO_IDENTIFICACION2`, `COD_GRUP_POBLACIONAL`, `COD_DEP`, `TAF_COD_AFILIADO`, `COD_ESTADO_AFILIACION2`, `COD_ARS`, `TIPO_IDENTIFICACION_CABEZA_FAMILIA`, `NUMERO_IDENTIFICACION_CABEZA_FAMILIA`, `TIPO_IDENTIFICACION`, `NUMERO_IDENTIFICACION`, `PRIMER_APELLIDO`, `SEGUNDO_APELLIDO`, `PRIMER_NOMBRE`, `SEGUNDO_NOMBRE`, `EDAD`, `FECHA_NACIMIENTO`, `SEXO`, `TIPO_AFILIADO`, `PARENTESCO_CABEZA_FAMILIA`, `GRUPO_POBLACIONAL`, `NIVEL_SISBEN`, `NUMERO_FICHA_SISBEN`, `NUCLEO_FAMILIAR_SISBEN`, `COD_DEPARTAMENTO`, `COD_MUNICIPIO`, `ZONA`, `FEC_AFILIACION_SGSSS`, `FEC_AFILIACION_ENTIDAD_CONTRATANTE`, `NUM_CONTRATO_ENTE_TERRITORIAL`, `FECHA_INICIO_CONTRATO_ENTE_TERRITORIAL`, `TIPO_CONTRATO_ENTE_TERRITORIAL`, `PERTENENCIA_ETNICA`, `ESTADO_AFILIACION`, `DIRECCION`, `TELEFONO`, `LOCALIDAD`, `FECHA_CARNETIZACION`, `BARRIO`, `COD_IPS`, `COD_CONTRATO`) VALUES 
('3238099', NULL, 'CC', '2', 'O', 'ESS207', 0, NULL, NULL, NULL, '2', 'CC', '5', '', NULL, NULL, '', '', '40276351', '', '17593231', 'BETANCOURT', '', 'RUBEN', 'DARIO', 338, '1978-11-09', 'M', '', '', '', 0, '38', '1', '11', '001', 'U', '2002-06-01', '2002-11-02', '024', '2004-04-01', 'CO', '6', 'AC', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('3238100', NULL, 'RC', '2', 'O', 'ESS207', 0, NULL, NULL, NULL, '2', 'CC', '5', '', NULL, NULL, '', '', '40276351', '', '23288644', 'BETANCOURT', '', 'DANI', 'ESPERANZA', 198, '1990-07-12', 'F', '', '', '', 0, '38', '1', '11', '001', 'U', '2002-06-01', '2002-11-02', '024', '2004-04-01', 'CO', '6', 'AC', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('3238101', NULL, 'RC', '2', 'O', 'ESS207', 0, NULL, NULL, NULL, '1', 'CC', '5', '', NULL, NULL, '', '', '40276351', '', '92110468470', 'BETANCUR', 'RAMIREZ', 'LEIDY', 'LAURA', 170, '1992-11-04', 'F', '', '', '', 0, '38', '1', '11', '001', 'U', '2002-06-01', '2003-10-27', '024', '2004-04-01', 'CO', '6', 'AC', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('3238140', NULL, 'TI', '2', 'O', 'ESS207', 0, NULL, NULL, NULL, '1', 'CC', '5', '', NULL, NULL, '', '', '19363796', '', '92033056666', 'MURILLO', 'ROMERO', 'DIEGO', '', 177, '1992-03-30', 'M', '', '', '', 0, '1663391', '1', '11', '001', 'U', '2002-06-01', '2002-06-25', '024', '2004-04-01', 'CO', '6', 'AC', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('3238167', NULL, 'RC', '2', 'O', 'ESS207', 0, NULL, NULL, NULL, '1', 'CC', '5', '', NULL, NULL, '', '', '52279593', '', '92011000136', 'POSADA', 'TORRES', 'ANGIE', 'PAOLA', 180, '1992-01-10', 'F', '', '', '', 0, '477482', '2', '11', '001', 'U', '2002-06-01', '2002-06-24', '024', '2004-04-01', 'CO', '6', 'AC', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('3238169', NULL, 'RC', '2', 'O', 'ESS207', 0, NULL, NULL, NULL, '1', 'CC', '5', '', NULL, NULL, '', '', '52279593', '', 'A6H0014447', 'POSADA', 'TORRES', 'NICOLAS', 'ALEJANDRO', 76, '2000-08-29', 'M', '', '', '', 0, '477482', '1', '11', '001', 'U', '2002-06-01', '2002-06-25', '024', '2004-04-01', 'CO', '6', 'AC', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('3238222', NULL, 'CC', '2', 'O', 'ESS207', 0, NULL, NULL, NULL, '2', 'CC', '5', '', NULL, NULL, '', '', '108302', '', '20306220', 'ARIAS', 'ALBINO', 'URANIA', '', 880, '1933-08-25', 'F', '', '', '', 0, '557898', '1', '11', '001', 'U', '2002-06-01', '2002-06-12', '024', '2004-04-01', 'CO', '6', 'AC', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('3238276', NULL, 'CC', '2', 'O', 'ESS207', 0, NULL, NULL, NULL, '1', 'CC', '5', '', NULL, NULL, '', '', '2496174', '', '79698592', 'BERNAL', 'VARGAS', 'LUIS', 'ALBERTO', 411, '1972-10-15', 'M', '', '', '', 0, '491210', '1', '11', '001', 'U', '2002-06-01', '2002-06-26', '024', '2004-04-01', 'CO', '6', 'AC', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('3238286', NULL, 'AS', '2', 'O', 'ESS207', 0, NULL, NULL, NULL, '2', 'CC', '5', '', NULL, NULL, '', '', '1095109', '', '11001219139', 'ARCO', 'SAINEA', 'MIGUEL', 'ANTONIO', 480, '1967-01-12', 'M', '', '', '', 0, '219', '1', '11', '001', 'U', '2002-06-01', '2002-06-13', '024', '2004-04-01', 'CO', '6', 'AC', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('3238314', NULL, 'CC', '2', 'O', 'ESS207', 0, NULL, NULL, NULL, '1', 'CC', '5', '', NULL, NULL, '', '', '19295132', '', '1023868265', 'GARCIA', 'CASTANEDA', 'IRMA', 'LEONOR', 241, '1986-12-04', 'F', '', '', '', 0, '1686066', '2', '11', '001', 'U', '2002-06-01', '2004-01-28', '024', '2004-04-01', 'CO', '6', 'AC', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('3238315', NULL, 'TI', '2', 'O', 'ESS207', 0, NULL, NULL, NULL, '1', 'CC', '5', '', NULL, NULL, '', '', '19295132', '', '89050354157', 'GARCIA', 'CASTANEDA', 'ANA', 'LUCIA', 212, '1989-05-03', 'F', '', '', '', 0, '1686066', '1', '11', '001', 'U', '2002-06-01', '2004-03-08', '024', '2004-04-01', 'CO', '6', 'AC', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('3238316', NULL, 'TI', '2', 'O', 'ESS207', 0, NULL, NULL, NULL, '1', 'CC', '5', '', NULL, NULL, '', '', '19295132', '', '90120160388', 'GARCIA', 'CASTANEDA', 'PABLO', 'OBDULIO', 193, '1990-12-01', 'M', '', '', '', 0, '1686066', '1', '11', '001', 'U', '2002-06-01', '2004-01-28', '024', '2004-04-01', 'CO', '6', 'AC', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('3238381', NULL, 'CC', '2', 'O', 'ESS207', 0, NULL, NULL, NULL, '1', 'TI', '5', '', NULL, NULL, '', '', '87020170857', '', '51819364', 'CACERES', '', 'MARGARITA', '', 498, '1965-07-02', 'F', '', '', '', 0, '501382', '1', '11', '001', 'U', '2002-06-01', '2004-03-02', '024', '2004-04-01', 'CO', '6', 'AC', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('3238384', NULL, 'CC', '2', 'O', 'ESS207', 0, NULL, NULL, NULL, '2', 'CC', '5', '', NULL, NULL, '', '', '19329377', '', '53045363', 'VARGAS', 'GARZON', 'ANGELICA', 'MARIA', 273, '1984-04-12', 'F', '', '', '', 0, '322', '1', '11', '001', 'U', '2002-06-01', '2002-06-20', '024', '2004-04-01', 'CO', '6', 'AC', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('3238385', NULL, 'RC', '2', 'O', 'ESS207', 0, NULL, NULL, NULL, '1', 'CC', '5', '', NULL, NULL, '', '', '19329377', '', '93083006097', 'VARGAS', 'GARZON', 'KATHERIN', 'LORENA', 160, '1993-08-30', 'F', '', '', '', 0, '501373', '1', '11', '001', 'U', '2002-06-01', '2002-06-20', '024', '2004-04-01', 'CO', '6', 'AC', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('3238409', NULL, 'RC', '2', 'O', 'ESS207', 0, NULL, NULL, NULL, '1', 'CC', '5', '', NULL, NULL, '', '', '79811487', '', '94040520505', 'SALAZAR', 'MONROY', 'JORGE', 'ANDRES', 153, '1994-04-05', 'M', '', '', '', 0, '361', '2', '11', '001', 'U', '2002-06-01', '2002-11-02', '024', '2004-04-01', 'CO', '6', 'AC', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('3238410', NULL, 'RC', '2', 'O', 'ESS207', 0, NULL, NULL, NULL, '1', 'CC', '5', '', NULL, NULL, '', '', '79811487', '', 'AYF0022392', 'SALAZAR', 'MONROY', 'MARIA', 'XIMENA', 82, '2000-03-19', 'F', '', '', '', 0, '361', '2', '11', '001', 'U', '2002-06-01', '2002-08-26', '024', '2004-04-01', 'CO', '6', 'AC', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('3238414', NULL, 'TI', '2', 'O', 'ESS207', 0, NULL, NULL, NULL, '1', 'CC', '5', '', NULL, NULL, '', '', '79703945', '', '780311050', 'RODRIGUEZ', '', 'CLAUDIA', 'MARCELA', 346, '1978-03-11', 'F', '', '', '', 0, '557958', '3', '11', '001', 'U', '2002-06-01', '2002-11-02', '024', '2004-04-01', 'CO', '6', 'AC', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('3238482', NULL, 'CC', '2', 'O', 'ESS207', 0, NULL, NULL, NULL, '1', 'CC', '5', '', NULL, NULL, '', '', '19259085', '', '41606463', 'CONTRERAS', 'PANQUEBA', 'GLADYS', '', 24, '2005-01-13', 'F', '', '', '', 0, '1047304', '1', '11', '001', 'U', '2000-06-01', '2002-06-24', '024', '2004-04-01', 'CO', '6', 'AC', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tcontrato`
-- 

CREATE TABLE `tcontrato` (
  `COD_CONTRATO` char(10) collate utf8_spanish_ci NOT NULL,
  `DESC_CONTRATO` char(100) collate utf8_spanish_ci default NULL,
  `FECHA_INICIO` date default NULL,
  `VIGENCIA` int(11) default NULL,
  `UPC` float(8,2) default NULL,
  `_UPC` decimal(10,0) default NULL,
  `CUPS` char(6) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`COD_CONTRATO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `tcontrato`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tcups`
-- 

CREATE TABLE `tcups` (
  `COD_CUPS` char(6) collate utf8_spanish_ci NOT NULL,
  `DESCRIPCION_CUPS` char(255) collate utf8_spanish_ci default NULL,
  `AREA` int(11) default NULL,
  PRIMARY KEY  (`COD_CUPS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `tcups`
-- 

INSERT INTO `tcups` (`COD_CUPS`, `DESCRIPCION_CUPS`, `AREA`) VALUES 
('197', 'OTRO CUPS PRG 1', 0),
('456', 'CUPS DEL PROGRAMA 1', 0);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tdepartamento`
-- 

CREATE TABLE `tdepartamento` (
  `COD_DEP` char(2) collate utf8_spanish_ci NOT NULL,
  `DEPARTAMENTO` char(30) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`COD_DEP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `tdepartamento`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tentidad_contratante`
-- 

CREATE TABLE `tentidad_contratante` (
  `COD_ENTIDAD_CONTRATANTE` char(6) collate utf8_spanish_ci NOT NULL,
  `DESC_ENTIDAD_CONTRATANTE` char(255) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`COD_ENTIDAD_CONTRATANTE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `tentidad_contratante`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tentidades_contratantes`
-- 

CREATE TABLE `tentidades_contratantes` (
  `COD_ENTIDAD_CONTRATANTE2` char(6) collate utf8_spanish_ci NOT NULL,
  `DESC_ARS` char(200) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`COD_ENTIDAD_CONTRATANTE2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `tentidades_contratantes`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `testados_afiliaciones`
-- 

CREATE TABLE `testados_afiliaciones` (
  `COD_ESTADO_AFILIACION2` char(2) collate utf8_spanish_ci NOT NULL,
  `DESC_ESTADO_AFILIACION` char(30) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`COD_ESTADO_AFILIACION2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `testados_afiliaciones`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tgrupos_poblacionales`
-- 

CREATE TABLE `tgrupos_poblacionales` (
  `COD_GRUP_POBLACIONAL` char(2) collate utf8_spanish_ci NOT NULL,
  `DESC_GRUP_POBLACIONAL` char(40) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`COD_GRUP_POBLACIONAL`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `tgrupos_poblacionales`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tmes`
-- 

CREATE TABLE `tmes` (
  `COD_MES` int(11) NOT NULL,
  `MES` char(10) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`COD_MES`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `tmes`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tmetas`
-- 

CREATE TABLE `tmetas` (
  `COD_META` int(11) NOT NULL auto_increment,
  `COD_PROGRAMA` int(11) default NULL,
  `COD_CUPS` char(6) collate utf8_spanish_ci default NULL,
  `PROGRAMA` int(11) default NULL,
  `FECHA_META_ANO` date default NULL,
  `AREALIZARANO` int(11) default NULL,
  PRIMARY KEY  (`COD_META`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `tmetas`
-- 

INSERT INTO `tmetas` (`COD_META`, `COD_PROGRAMA`, `COD_CUPS`, `PROGRAMA`, `FECHA_META_ANO`, `AREALIZARANO`) VALUES 
(1, 123, NULL, NULL, NULL, 25);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tmp`
-- 

CREATE TABLE `tmp` (
  `COD_AFILIADO` char(13) collate utf8_spanish_ci NOT NULL,
  `COD_MUN` char(3) collate utf8_spanish_ci default NULL,
  `COD_TIPO_IDENTIFICACION2` char(3) collate utf8_spanish_ci default NULL,
  `COD_PARENTESCO2` char(1) collate utf8_spanish_ci default NULL,
  `COD_TIPO_AFILIADO2` char(1) collate utf8_spanish_ci default NULL,
  `COD_ENTIDAD_CONTRATANTE2` char(6) collate utf8_spanish_ci default NULL,
  `COD_TIPO_CONTRATO` int(11) NOT NULL,
  `COD_ZONA2` char(1) collate utf8_spanish_ci default NULL,
  `COD_SEXO2` char(2) collate utf8_spanish_ci default NULL,
  `COD_PERTENENCIA_ETNICA2` char(2) collate utf8_spanish_ci default NULL,
  `COD_NIVEL_SISBEN2` char(1) collate utf8_spanish_ci default NULL,
  `TTI_COD_TIPO_IDENTIFICACION2` char(3) collate utf8_spanish_ci default NULL,
  `COD_GRUP_POBLACIONAL` char(2) collate utf8_spanish_ci default NULL,
  `COD_DEP` char(2) collate utf8_spanish_ci NOT NULL,
  `TAF_COD_AFILIADO` char(13) collate utf8_spanish_ci default NULL,
  `COD_ESTADO_AFILIACION2` char(2) collate utf8_spanish_ci default NULL,
  `COD_ARS` char(6) collate utf8_spanish_ci NOT NULL,
  `TIPO_IDENTIFICACION_CABEZA_FAMILIA` char(3) collate utf8_spanish_ci NOT NULL,
  `NUMERO_IDENTIFICACION_CABEZA_FAMILIA` char(16) collate utf8_spanish_ci NOT NULL,
  `TIPO_IDENTIFICACION` char(3) collate utf8_spanish_ci NOT NULL,
  `NUMERO_IDENTIFICACION` char(16) collate utf8_spanish_ci NOT NULL,
  `PRIMER_APELLIDO` char(20) collate utf8_spanish_ci NOT NULL,
  `SEGUNDO_APELLIDO` char(20) collate utf8_spanish_ci NOT NULL,
  `PRIMER_NOMBRE` char(20) collate utf8_spanish_ci NOT NULL,
  `SEGUNDO_NOMBRE` char(20) collate utf8_spanish_ci NOT NULL,
  `EDAD` int(11) NOT NULL,
  `FECHA_NACIMIENTO` date NOT NULL,
  `SEXO` char(2) collate utf8_spanish_ci NOT NULL,
  `TIPO_AFILIADO` char(1) collate utf8_spanish_ci NOT NULL,
  `PARENTESCO_CABEZA_FAMILIA` char(1) collate utf8_spanish_ci NOT NULL,
  `GRUPO_POBLACIONAL` char(1) collate utf8_spanish_ci NOT NULL,
  `NIVEL_SISBEN` int(11) NOT NULL,
  `NUMERO_FICHA_SISBEN` char(13) collate utf8_spanish_ci NOT NULL,
  `NUCLEO_FAMILIAR_SISBEN` char(5) collate utf8_spanish_ci NOT NULL,
  `COD_DEPARTAMENTO` char(2) collate utf8_spanish_ci NOT NULL,
  `COD_MUNICIPIO` char(3) collate utf8_spanish_ci NOT NULL,
  `ZONA` char(1) collate utf8_spanish_ci NOT NULL,
  `FEC_AFILIACION_SGSSS` date NOT NULL,
  `FEC_AFILIACION_ENTIDAD_CONTRATANTE` date NOT NULL,
  `NUM_CONTRATO_ENTE_TERRITORIAL` char(10) collate utf8_spanish_ci NOT NULL,
  `FECHA_INICIO_CONTRATO_ENTE_TERRITORIAL` date NOT NULL,
  `TIPO_CONTRATO_ENTE_TERRITORIAL` char(2) collate utf8_spanish_ci NOT NULL,
  `PERTENENCIA_ETNICA` char(2) collate utf8_spanish_ci NOT NULL,
  `ESTADO_AFILIACION` char(2) collate utf8_spanish_ci NOT NULL,
  `DIRECCION` char(30) collate utf8_spanish_ci default NULL,
  `TELEFONO` char(20) collate utf8_spanish_ci default NULL,
  `LOCALIDAD` char(2) collate utf8_spanish_ci default NULL,
  `FECHA_CARNETIZACION` date default NULL,
  `BARRIO` char(30) collate utf8_spanish_ci default NULL,
  `COD_IPS` char(11) collate utf8_spanish_ci default NULL,
  `COD_CONTRATO` char(10) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`COD_AFILIADO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `tmp`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tmunicipio`
-- 

CREATE TABLE `tmunicipio` (
  `COD_MUN` char(3) collate utf8_spanish_ci NOT NULL,
  `COD_DEP` char(2) collate utf8_spanish_ci NOT NULL,
  `DESC_MUNICIPIO` char(20) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`COD_MUN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `tmunicipio`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tnivel_sisben2`
-- 

CREATE TABLE `tnivel_sisben2` (
  `COD_NIVEL_SISBEN2` char(1) collate utf8_spanish_ci NOT NULL,
  `DESC_NIVEL_SISBEN` char(30) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`COD_NIVEL_SISBEN2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `tnivel_sisben2`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tparentescos`
-- 

CREATE TABLE `tparentescos` (
  `COD_PARENTESCO2` char(1) collate utf8_spanish_ci NOT NULL,
  `DESC_PARENTESCO` char(30) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`COD_PARENTESCO2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `tparentescos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tpertenencia_etnica2`
-- 

CREATE TABLE `tpertenencia_etnica2` (
  `COD_PERTENENCIA_ETNICA2` char(2) collate utf8_spanish_ci NOT NULL,
  `DESC_PERTENENCIA_ETNICA` char(30) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`COD_PERTENENCIA_ETNICA2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `tpertenencia_etnica2`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tprogramas`
-- 

CREATE TABLE `tprogramas` (
  `COD_PROGRAMA` int(11) NOT NULL,
  `COD_ACT_CONTRATADA` int(10) NOT NULL,
  `NOMBRE_PROGRAMA` char(30) collate utf8_spanish_ci default NULL,
  `DETALLE_PROGRAMA` text collate utf8_spanish_ci,
  PRIMARY KEY  (`COD_PROGRAMA`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `tprogramas`
-- 

INSERT INTO `tprogramas` (`COD_PROGRAMA`, `COD_ACT_CONTRATADA`, `NOMBRE_PROGRAMA`, `DETALLE_PROGRAMA`) VALUES 
(123, 456, 'PROGRAMA 1', 'ESTE PROGRAMA ES UNA PRUEBA PARA VER SI FUNCIONA EL ALGORITMO.');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tsexos`
-- 

CREATE TABLE `tsexos` (
  `COD_SEXO2` char(2) collate utf8_spanish_ci NOT NULL,
  `DESC_SEXO` char(30) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`COD_SEXO2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `tsexos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `ttipo_contrato`
-- 

CREATE TABLE `ttipo_contrato` (
  `COD_TIPO_CONTRATO` int(11) NOT NULL auto_increment,
  `DES_TIPO_CONTRATO` char(20) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`COD_TIPO_CONTRATO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `ttipo_contrato`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `ttipoact`
-- 

CREATE TABLE `ttipoact` (
  `COD_ACT` int(11) NOT NULL,
  `TIPO_ACTUALIZACION` int(11) default NULL,
  PRIMARY KEY  (`COD_ACT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `ttipoact`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `ttipos_afiliado`
-- 

CREATE TABLE `ttipos_afiliado` (
  `COD_TIPO_AFILIADO2` char(1) collate utf8_spanish_ci NOT NULL,
  `DESC_AFILIADO` char(40) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`COD_TIPO_AFILIADO2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `ttipos_afiliado`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `ttipos_de_identificacion`
-- 

CREATE TABLE `ttipos_de_identificacion` (
  `COD_TIPO_IDENTIFICACION2` char(3) collate utf8_spanish_ci NOT NULL,
  `DESC_DOC_TIP` char(30) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`COD_TIPO_IDENTIFICACION2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `ttipos_de_identificacion`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tvigenciafiltros`
-- 

CREATE TABLE `tvigenciafiltros` (
  `COD_ACTIVIDAD` decimal(10,0) NOT NULL,
  `COD_CUPS` char(6) collate utf8_spanish_ci NOT NULL,
  `COD_GRUPO` int(10) NOT NULL,
  `ESTADO` tinyint(1) default NULL,
  PRIMARY KEY  (`COD_ACTIVIDAD`,`COD_CUPS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `tvigenciafiltros`
-- 

INSERT INTO `tvigenciafiltros` (`COD_ACTIVIDAD`, `COD_CUPS`, `COD_GRUPO`, `ESTADO`) VALUES 
(258, '456', 100, 1),
(369, '147', 101, 1),
(789, '456', 99, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tzonas`
-- 

CREATE TABLE `tzonas` (
  `COD_ZONA2` char(1) collate utf8_spanish_ci NOT NULL,
  `DESC_ZONA` char(30) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`COD_ZONA2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `tzonas`
-- 

